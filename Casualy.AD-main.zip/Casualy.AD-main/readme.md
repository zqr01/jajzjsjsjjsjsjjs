npm install discord.js
npm install quick.db

Albo npm i .


potem edytujesz Id rang do weryfikacji i dzialasz Good luck